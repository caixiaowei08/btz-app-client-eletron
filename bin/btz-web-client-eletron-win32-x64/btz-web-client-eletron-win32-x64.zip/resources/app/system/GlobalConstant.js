/**
 * Created by User on 2017/5/24.
 */
var GLOBAL_CONSTANT_URL = "http://114.55.110.110:8080/";
//var GLOBAL_CONSTANT_URL = "http://localhost:8080/";